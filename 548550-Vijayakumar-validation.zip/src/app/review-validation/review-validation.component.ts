import { Component, OnInit, ɵConsole } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-product-form',
  templateUrl: './review-validation.component.html',
  styleUrls: ['./review-validation.component.css']
})
export class ReviewComponent implements OnInit {
	
	formName: FormGroup;
	submitted = false;

	constructor(private fb: FormBuilder) { }

	get fn(){
		return this.formName.controls;
	}

	submit(){
		console.log(this.formName.value);
	}
	
	
	ngOnInit() {
		this.formName = this.fb.group({
		   numberInput: ['', [validator.phoneValidator]],
		   reviewInput:['', [validator.commentValidator]]
		});
	}
	
}

class validator{

static phoneValidator(number): any {
  if (number.pristine) {
     return null;
  }
  const PHONE_REGEXP = /^(\([0-9]{3}\) |[0-9]{3}-)[0-9]{3}-[0-9]{4}$/;
  number.markAsTouched();
  if (PHONE_REGEXP.test(number.value)) {
     return null;
  }
  return {
     invalidNumber: true
  };
}

static commentValidator(str, words, names): any {
  if (str.pristine) {
     return null;
  }
 
 words=['Idiot','Stupid','bad'];
 names=['christy','evans', 'lucy'];
 var reviewComment = str.value;
 var regex = new RegExp("\\b(?:" + words.join("|") + "|" + names.join("|") + ")\\b", "gi");
 if (reviewComment.match(regex) == null)
    return false;
 return {
     invalidComment: true
  };
}

}