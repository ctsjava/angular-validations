import { Component } from "@angular/core";
import { FormGroup, FormBuilder, Validators } from "@angular/forms";

class CustomValidator {
  // Validates US phone numbers
  static phoneValidator(number): any {
    if (number.pristine) {
      return null;
    }
    const PHONE_REGEXP = /^(\([0-9]{3}\) |[0-9]{3}-)[0-9]{3}-[0-9]{4}$/;
    number.markAsTouched();
    if (PHONE_REGEXP.test(number.value)) {
      return null;
    }
    return {
      invalidNumber: true
    };
  }

  static wordsValidator(textReview): any {
    if (textReview.value.pristine) {
      return null;
    }

    let badWords = ["idiot", "stupid", "hell"];

    if (badWords.includes(textReview.value))
    {       
      return {         
        invalidReview: true
      };
   }
  }
}
@Component({
  selector: "app-root",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent {
  formName: FormGroup;
  submitted = false;

  constructor(private fb: FormBuilder) {}
  errors: any = [];
  ngOnInit() {
    this.formName = this.fb.group({
      numberInput: ["", [CustomValidator.phoneValidator]],
      review: ["", [CustomValidator.wordsValidator]]
    });
  }

  get fn() {
    return this.formName.controls;
  }

  submit() {
    console.log(this.formName.value);
  }
}
