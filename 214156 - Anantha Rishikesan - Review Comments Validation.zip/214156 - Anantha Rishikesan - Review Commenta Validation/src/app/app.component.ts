import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

class CustomValidator{

static phoneValidator(number): any {
  if (number.pristine) {
     return null;
  }
  const PHONE_REGEXP = /^(\([0-9]{3}\) |[0-9]{3}-)[0-9]{3}-[0-9]{4}$/;
  number.markAsTouched();
  if (PHONE_REGEXP.test(number.value)) {
     return null;
  }
  return {
     invalidNumber: true
  };
}

static commentValidator(str, words, names): any {
  if (str.pristine) {
     return null;
  }
 
 words=['Idiot','Stupid','bad'];
 names=['prabhu','praveen', 'rishi'];
 var reviewComment = str.value;
    var regexMetachars = /[(){[*+?.\\^$|]/g;

    for (var i = 0; i < words.length; i++) {
        words[i] = words[i].replace(regexMetachars, "\\$&");
    }
    for (var i = 0; i < names.length; i++) {
        names[i] = names[i].replace(regexMetachars, "\\$&");
    }
   words = words.concat(names);

    var regex = new RegExp("\\b(?:" + words.join("|") + ")\\b", "gi");

    if (reviewComment.match(regex) == null)
    return false;

  return {
     invalidComment: true
  };
}

}
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  formName: FormGroup;
  submitted = false;
  
  constructor(private fb: FormBuilder) { }

  ngOnInit() {
    this.formName = this.fb.group({
       numberInput: ['', [CustomValidator.phoneValidator]],
       reviewInput:['', [CustomValidator.commentValidator]]
    });
 }

  get fn(){
    return this.formName.controls;
  }



 submit(){
   console.log(this.formName.value);
   
 }
  }



    
 
  

